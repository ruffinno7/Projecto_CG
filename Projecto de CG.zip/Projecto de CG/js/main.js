var configuracoes= {
    type: Phaser.AUTO,
    whidth: 750,
    height: 550,
    physics:{
        default: 'arcade',
        arcade:{
            gravity:{y:300},
            debub: false
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update,
    }
        
    }


var game = new Phaser.Game(configuracoes)
var chao;
var barra;
var player;
var text;
var fundo;
function preload(){
    this.load.image('sky', '../imagens/fundo1.png');
    this.load.image('chao', '../imagens/chao.png');
    this.load.image('barra', '../imagens/barra.png');
    this.load.image('bomb', '../imagens/bomb.png');
    this.load.image('taxi', '../imagens/taxi.png');
    this.load.image('player', '../imagens/player.png');
}

function create(){
    fundo = this.physics.add.staticGroup();
    fundo.create(500, 240, 'sky').setScale(5).refreshBody();
    chao = this.physics.add.staticGroup();
    chao.create(0, 560, 'chao').setScale(11).refreshBody();
    barra = this.physics.add.staticGroup();
    
    barra.create(700, 410, 'barra');
    barra.create(900, 310, 'barra');
    
    this.add.image(600,450, 'taxi');
    this.add.image(400,450, 'taxi');
    this.add.image(850,350, 'taxi');
    

    
    
}

function update(){

}
